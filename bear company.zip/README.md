

//𝐂𝐑𝐄𝐀𝐓𝐄𝐃 : DEVELOPER ( Ryyy )
//𝐂𝐎𝐍𝐓𝐀𝐂𝐓 : https://t.me/ryyyawhh
//𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 : https://wa.me/6288287577173
//𝐆𝐈𝐓𝐇𝐔𝐁 : https://ryyyawh.com


require('./settings');
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const speed = require('performance-now');
const similarity = require('similarity');
const Img = fs.readFileSync('./lib/Image/menu.jpg')
const Img2 = fs.readFileSync('./lib/Image/bugging.jpg')
const G1 = fs.readFileSync('./lib/Image/ryy.jpg')
const G2 = fs.readFileSync('./lib/Image/anjay.jpg')
const G3 = fs.readFileSync(./lib/Image/mantap.jpg')
const { spawn, exec, execSync } = require('child_process');

const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType, 
prepareWAMessageMedia } = require("@whiskeysockets/baileys");

module.exports = Neverdie = async (Neverdie, m, chatUpdate, store) => {
try {
// Message type handlers
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? Neverdie.user.id.split(":")[0] || Neverdie.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';

// Buat Grup
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database And Lain"
const botNumber = await Neverdie.decodeJid(Neverdie.user.id);
const isBot = botNumber.includes(senderNumber)
const newOwner = JSON.parse(fs.readFileSync("./lib/Database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./lib/Database/premium.json"))

const isPremium = premium.includes(m.sender)
const isOwner = newOwner.includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// function Group
const groupMetadata = isGroup ? await Neverdie.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// My Func
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep } = require('./lib/myfunc');

//function loading
async function loadingl() {
    var arr = [
        "𝐓𝐇𝐄",
         "𝐆𝐈𝐋𝐁𝐎𝐘",
          "𝐃𝐈𝐒𝐏𝐋𝐀𝐘𝐈𝐍𝐆",
           "𝐌𝐄𝐍𝐔",
            "𝐖𝐀𝐈𝐓",
             "𝐅𝐎𝐑",
              "𝟏",
               "𝐒𝐄𝐂𝐂𝐎𝐍𝐃",
                "𝐗𝐍𝐄𝐕𝐄𝐑𝐃𝐈𝐄 𝐑𝐄𝐌𝐀𝐒𝐓𝐑𝐄𝐃 𝐒𝐄𝐀𝐒𝐒𝐎𝐍 𝟐 𝐈𝐒 𝐑𝐄𝐃𝐘"
    ];
    let load = await Neverdie.sendMessage(from, {text: '🌋'}, {quoted: m});
    for (let i = 0; i < arr.length; i++) {
        await sleep(100);
        await Neverdie.sendMessage(from, {text: arr[i], edit: load.key}, {quoted: m});
    }
}

async function loading() {
    var arr = [
        `${pushname}: *${command}*`,
        "...",
        "\`</>𝐋𝐎𝐀𝐒𝐈𝐍𝐆 𝐈𝐒 𝐒𝐔𝐂𝐂𝐄𝐒𝐄𝐃 𝐗𝐍𝐄𝐕𝐄𝐑𝐃𝐈𝐄 𝐆𝐄𝐍 𝟏 𝐒𝐄𝐀𝐒𝐒𝐎𝐍 𝟐 𝐃𝐈𝐒𝐏𝐋𝐀𝐘𝐈𝐍𝐆 𝐌𝐄𝐍𝐔✓</>\`"
    ];
    let load = await Neverdie.sendMessage(from, {text: 'loading..'}, {quoted: m});
    for (let i = 0; i < arr.length; i++) {
        await sleep(100);
        await Neverdie.sendMessage(from, {text: arr[i], edit: load.key}, {quoted: m});
    }
}


// fungsi waktu real time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Cmd in Console
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`➤ New Messages`));
console.log(
chalk.bgHex("#00FF00").black(
` ╭─ > Tanggal: ${new Date().toLocaleString()} \n` +
` ├─ > Pesan: ${m.body || m.mtype} \n` +
` ├─ > Pengirim: ${m.pushname} \n` +
` ╰─ > JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
` ╭─ > Grup: ${groupName} \n` +
` ╰─ > GroupJid: ${m.chat}`
)
);
}
console.log();
} 

//AWAL FUNC BUGGG

//ISI BG RYY

// AKHIR FUNC BUG
//=======================================\\

        // Random Emoji //
        
const Moji1 = '🦠'
const Moji2 = '🌟'
const Moji3 = '♦️'
const ERandom = [Moji1, Moji2, Moji3]
let Feature = Math.floor(Math.random() * ERandom.length)
const emoji = ERandom[Feature]

        // Thumb Botz //

const thumb = fs.readFileSync('./lib/Image/thumb.jpg');

if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('gillboy.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `▢ Halo Kak, Apakah kakak sedang mencari ${prefix+mean}?\n▢ Nama menu : ${prefix+mean}`
Neverdie.sendMessage(m.chat, { image: thumb, caption: response }, {quoted: m})
}}

const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `© 𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃`,
      jpegThumbnail: ""
    }
  }, 
quoted: sound
} 

const loli = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: thumb,
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const reply = (teks) => { 
Neverdie.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `⃟𝐑𝐲𝐲𝐲̶͠𝐒𝐮𝐩𝐩𝐞𝐫̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭𝐞̶͠𝟒𝐘𝐨𝐮𝐮𝐮͢͠⃟ `,"body": `© 𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃`, "previewType": "PHOTO","thumbnailUrl": `https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=${command}`}}}, { quoted: hw})} 

const reaction = async (jidss, emoji) => {
Neverdie.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

switch (command) {

case 'neverdie': 
case 'menu': {
await loadingl()
await loading()
let menu = `
╔╗╔╦═╦╗──────────╔╦╗──
╚╗╔╣║║╠═╦═╦═╦═╦╦╦╝╠╬═╗
╔╝╚╣║║║╩╬╗║╔╣╩╣╔╣╬║║╩╣
╚╝╚╩╩═╩═╝╚═╝╚═╩╝╚═╩╩═╝
╔══╗────╔═╗─────╔══╗—
║══╬═╦═╗║═╬═╦═╦╗╠══║—
╠══║╩╣╬╚╬═║╬║║║║║══╣—
╚══╩═╩══╩═╩═╩╩═╝╚══╝—
─╔═╦╦╦╦╗─╔╗──────
─║╬║║║║║╔╝╠═╦═╦═╗
─║╗╬╗╠╗║║╬║╩╬╗║╔╝
─╚╩╩═╩═╝╚═╩═╝╚═╝─

    ✪ 〈 𝚁𝚈𝚈𝙰𝙻𝙿𝙷𝙰 〉 ✪

➫ 𝐍𝐀𝐌𝐄 𝐁𝐎𝐓 : !𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ♱ 𝐃͜𝐈͡𝐄¡ 
➫ 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 𝟐.𝟎.𝟎 𝐑𝐄𝐌𝐀𝐒𝐓𝐑𝐄𝐃
➫ 𝐔𝐒𝐄𝐑 : 𝐕𝐈𝐏 𝐁𝐔𝐘 𝐎𝐍𝐋𝐘
➫ 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑 : ⃟ ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ 
➫ 𝐒𝐄𝐀𝐒𝐒𝐎𝐍 : 𝟐
========================
╔═╦═╦╦═╦╦══╦╗╔═╦╗╔╦══╗
║╬╠╗║╠╗║║╔╗║║║╬║╚╝║╔╗║
║╗╬╩╗╠╩╗║╠╣║╚╣╔╣╔╗║╠╣║
╚╩╩══╩══╩╝╚╩═╩╝╚╝╚╩╝╚╝
========================
✪ *〈 𝐅𝐘𝐈 〉* ✪
\`𝚃𝙷𝙴 𝚂𝙲𝚁𝙸𝙿𝚃 𝙲𝚁𝙴𝙰𝚃𝙴𝙳 𝙾𝙽 𝚁𝚢𝚢𝙰𝚕𝚙𝚑𝚊\`
\`𝙳𝙾 𝚈𝙾𝚄 𝙱𝚄𝚈 𝚂𝙲𝚁𝙸𝙿𝚃? 𝙲𝙷𝙰𝚃 𝙼𝙴!! https://wa.me/+5518981337852\`

[ 𝙱𝙸𝙶 𝚃𝙷𝙰𝙽𝙺𝚂 𝚃𝙾 ]  
 -𝙰𝙻𝙻𝙰𝙷 𝚂𝚆𝚃 [ 𝙼𝚈 𝙶𝙾𝙳 ]  
 -𝚁𝚈𝚈𝚈 [ ᴍʏ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ]
 -𝙾𝚁𝚃𝚄 [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]   
 -𝙻𝚆𝙴𝙽𝙽 [ 𝚃𝙴𝙰𝙲𝙷𝙴𝚁 ]   
 -𝙵𝙰𝚁𝚁𝙴𝙻𝙾𝙵𝙵𝙲 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙹𝚄𝙰𝙽𝙽 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙳𝚁𝚈𝚇𝚉 [ 𝙼𝚅𝙰𝙰? ]
 -𝚂𝙺𝚈𝚈 𝙱𝙾𝙲𝙰𝙷 𝙴𝙿𝙴𝙿 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙷𝙰𝙽𝙽𝚅𝙾𝙻𝚃𝙰 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝚁𝙰𝙵𝙵𝟺𝚄 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙿𝙸𝚉𝚉 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝚄𝚂𝙴𝙽𝙸𝙽𝙶 𝚂𝙲𝚁𝙸𝙿𝚃 [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]
`
let buttons = [
        { buttonId: ".tqto", buttonText: { displayText: "Thanks To" } }
    ];

    let buttonMessage = {
        image: Img,
	    gifPlayback: true,
        caption: menu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363390660011889@newsletter",
                newsletterName: `Ch abang gantenk `
            }
        },
        footer: "© !𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ♱ 𝐃͜𝐈͡𝐄¡ — 𝐒𝐄𝐀𝐒𝐒𝐎𝐍 𝟐 ",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "©︎ Menu",
                    sections: [
                        {
                            title: "Please Chose One",
                            highlight_label: "",
                            rows: [
                                { title: "𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔", description: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ ", id: ".ownermenu" },
                                { title: "𝐁𝐔𝐆 𝐌𝐄𝐍𝐔", description: " *!𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ♱ 𝐃͜𝐈͡𝐄¡ 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 𝟐*", id: ". remastered" }
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

    await Neverdie.sendMessage(m.chat, buttonMessage, { quoted: loli });
};
break

case "remastered": {
await loadingl()
await loading()
let msgbug = `
╭━╮╭━╮
╰╮╰╯╭╯
╱╰╮╭╯╱
╱╭╯╰╮╱
╭╯╭╮╰╮
╰━╯╰━╯
┏━┳┳━┳┓╋┏┳━┳━┳━━┳━━┳━┓
┃┃┃┃┳┫┗┳┛┃┳┫╋┣┓┓┣┃┃┫┳┛
┃┃┃┃┻╋┓┃┏┫┻┫┓╋┻┛┣┃┃┫┻┓
┗┻━┻━┛┗━┛┗━┻┻┻━━┻━━┻━┛
┏┓┏┳┓┏━━┳━━┳━┳━┳━━┳━━┳━┓
┃┃┃┃┃┗┓┏┻┃┃┫┃┃┃┃┏┓┣┓┏┫┳┛
┃┗┛┃┗┓┃┃┏┃┃┫┃┃┃┃┏┓┃┃┃┃┻┓
┗━━┻━┛┗┛┗━━┻┻━┻┻┛┗┛┗┛┗━┛
┏━━┳━┳━━┳━━┳━━┳━┳━┳┓┏━━┓
┃━━┫┳┫┏┓┃━━┫━━┫┃┃┃┃┃┣━━┃
┣━━┃┻┫┏┓┣━━┣━━┃┃┃┃┃┃┃━━┫
┗━━┻━┻┛┗┻━━┻━━┻━┻┻━┛┗━━┛
========================
╔═╦═╦╦═╦╦══╦╗╔═╦╗╔╦══╗
║╬╠╗║╠╗║║╔╗║║║╬║╚╝║╔╗║
║╗╬╩╗╠╩╗║╠╣║╚╣╔╣╔╗║╠╣║
╚╩╩══╩══╩╝╚╩═╩╝╚╝╚╩╝╚╝
========================
╭━━━┳━━━━┳╮╭━┳━━━╮
┃╭━╮┃╭╮╭╮┃┃┃╭┫╭━━╯
┃╰━╯┃╭━━╮┃╰╯╯┃╰━━╮
┃╭━━┫┃┃┃┃┃╭╮┃┃╭━━╯
┃┃╱╱┃╰━━╯┃┃┃╰┫╰━━╮
╰╯╱╱╰━━━━┻╯╰━┻━━━╯
╭━━━┳━━━┳╮╱╭┳━━━┳━━━┳╮╱╭╮
┃╭━╮┃╭━╮┃┃╱┃┃╭━╮┃╭━╮┃┃╱┃┃
┃┃╱╰┫┃╱┃┃┃╱┃┃╰━━┫┃╱┃┃╰━╯┃
┃┃╭━┫╰━╯┃┃╱┃┣━━╮┃╰━╯┃╭━╮┃
┃╰┻━┃╭━╮┃╰━╯┃╰━╯┃╭━╮┃┃╱┃┃
╰━━━┻╯╱╰┻━━━┻━━━┻╯╱╰┻╯╱╰╯
╱╭━━━┳━━━┳╮╭━┳━━━╮
╱┃╭━╮┃╭━╮┃┃┃╭┫╭━━╯
╱┃╰━╯┃┃╱┃┃╰╯╯┃╰━━╮
╱┃╭━━┫╰━╯┃╭╮┃┃╭━━╯
╱┃┃╱╱┃╭━╮┃┃┃╰┫╰━━╮
╱╰╯╱╱╰╯╱╰┻╯╰━┻━━━╯
╭━━╮╭━━━━┳━━━┳━━━━╮
┃╭╮┃┃╭╮╭╮┣╮╭╮┃╭╮╭╮┃
┃╰╯╰┫╭━━╮┃┃┃┃┃╭━━╮┃
┃╭━╮┃┃┃┃┃┃┃┃┃┃┃┃┃┃┃
┃╰━╯┃╰━━╯┣╯╰╯┃╰━━╯┃
╰━━━┻━━━━┻━━━┻━━━━╯
========================
╔═╦═╦╦═╦╦══╦╗╔═╦╗╔╦══╗
║╬╠╗║╠╗║║╔╗║║║╬║╚╝║╔╗║
║╗╬╩╗╠╩╗║╠╣║╚╣╔╣╔╗║╠╣║
╚╩╩══╩══╩╝╚╩═╩╝╚╝╚╩╝╚╝
========================
☭  𝐗𝐍𝐞𝐯𝐞𝐫
☭  '𝐒𝐄𝐀𝐒𝐒𝐎𝐍𝟐-𝐂𝐑𝐀𝐒𝐇𝐈𝐍𝐆
☭  𝐑𝐘𝐘𝐒𝐀𝐘𝐀𝐍𝐆𝐊𝐘𝐎𝐌𝐈
☭  𝐑𝐘𝐘𝐆𝐀𝐌𝐎𝐍
☭  𝐒𝐔𝐏𝐏𝐄𝐑𝐂𝐑𝐀𝐒𝐇
☭  𝐔𝐈
☭  𝐒𝐘𝐒𝐓𝐄𝐌
========================
ᖴOOᖇ YOᑌ IᑎᖴOᖇᗰᗩTIOᑎ
========================

\`𝙿𝙻𝙴𝙰𝚂𝙴 𝙿𝙰𝚄𝚂𝙴𝙳 𝟷𝟻 𝙼𝙴𝙽𝙸𝚃𝚄𝙳𝙴 𝙵𝙾𝚁 𝚄𝚂𝙴𝙽𝙸𝙽𝙶 𝚂𝙲𝚁𝙸𝙿𝚃 𝙰𝙽𝙳 𝙽𝙾 𝙺𝙴𝙽𝙾𝙽!!\`
\`𝚃𝙷𝙴 𝚂𝙲𝚁𝙸𝙿𝚃 𝙲𝚁𝙴𝙰𝚃𝙴𝙳 𝙾𝙽 𝚁𝚢𝚢𝙰𝚕𝚙𝚑𝚊\`
\`𝙳𝙾 𝚈𝙾𝚄 𝙱𝚄𝚈 𝚂𝙲𝚁𝙸𝙿𝚃? 𝙲𝙷𝙰𝚃 𝙼𝙴!! https://wa.me/+5518981337852\`
`
let buttons = [
        { buttonId: ".owner", buttonText: { displayText: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ " } }, 
        { buttonId: ".tqto", buttonText: { displayText: "𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 𝟐" } }
    ];

    let buttonMessage = {
        image: Img2
	    gifPlayback: true,
        caption: msgbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363390660011889@newsletter",
                newsletterName: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ "
            }
        },
        footer: "© 𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃! 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 𝐓𝐖𝐎",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await Neverdie.sendMessage(m.chat, buttonMessage, { quoted: loli });
}
break
// Case Tools
case "encrypthard": case "enchard" : {

if (!m.quoted) return m.reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await m.reply("𝙿𝚁𝙾𝙲𝙴𝚂𝚂𝙸𝙽𝙶 𝙴𝙽𝙲𝙷𝙰𝚁𝙳 . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "素晴座素晴難𝐃𝐎𝐘𝐎𝐔𝐊𝐍𝐎𝐖𝐑𝐘𝐘𝐘素晴座素晴難" + 
            "素晴座素晴難𝐃𝐎𝐘𝐎𝐔𝐊𝐍𝐎𝐖𝐑𝐘𝐘素晴座素晴難";
        
        // Fungsi untuk menghapus karakter yang tidak diinginkan
        function removeUnwantedChars(input) {
            return input.replace(
                /[^a-zA-Z座𝚁𝚈𝚈𝚇𝙽𝙴𝚅𝙴𝚁素𝚇𝙽𝙴𝚅𝙴𝚁𝙳𝙸𝙴素晴]/g, ''
            );
        }

        // Fungsi untuk menghasilkan string acak
        function randomString(length) {
            let result = '';
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; // Hanya simbol
            const charactersLength = characters.length;

            for (let i = 0; i < length; i++) {
                result += characters.charAt(
                    Math.floor(Math.random() * charactersLength)
                );
            }
            return result;
        }

        return removeUnwantedChars(originalString) + randomString(2);
    },

   renameVariables: true,
    renameGlobals: true,

    stringEncoding: true,
    stringSplitting: 0.0,
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: 1.0,

    shuffle: {
        hash: 0.0,
        true: 0.0
    },

    stack: true,
    controlFlowFlattening: 1.0,
    opaquePredicates: 0.9,
    deadCode: 0.0,
    dispatcher: true,
    rgf: false,
    calculator: true,
    hexadecimalNumbers: true,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true 
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await Neverdie.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break
case 'seasson2-crashing': case ryyysayangkyomi': case 'xnever': case 'ryygamon': case 'suppercrash': case 'system': case 'ui': {
if (!isBot) return reply('𝐊𝐇𝐔𝐒𝐔𝐒 𝐌𝐔𝐑𝐁𝐔𝐆 𝐑͢𝐲𝐲͜𝟒͡𝐘͜𝐨͡𝐮͜𝐮͡𝐮͢͢͠⃟  ')
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒𝐒𝐈𝐍𝐆 𝐁𝐔𝐆 𝐏𝐋𝐄𝐀𝐒𝐄 𝐃𝐎𝐍'𝐓 SPAM☭☭`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 — 𝐗𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 𝐒𝟐 ♱ ')
// Memulai Crashing
   for (let i = 0; i < 100; i++) {
//NANTI DI ISI BG RYY KOOO AMAN AJAA⚉⚉
Neverdie.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
 await sleep(1000);
}
break
case "tqto": {
await loadingl()
await loading()
let tqtoo = `
█▀▄ █ ▄▀▀░
█▀█ █ █░▀▌
▀▀░ ▀ ▀▀▀░
▀█▀ █░█ ▄▀▄ █▄░█ █░▄▀ ▄▀▀
░█░ █▀█ █▀█ █░▀█ █▀▄░ ░▀▄
░▀░ ▀░▀ ▀░▀ ▀░░▀ ▀░▀▀ ▀▀░
▀█▀ ▄▀▄
░█░ █░█
░▀░ ░▀░

▀▄▀▄ 𝘽𝙄𝙂 𝙏𝙃𝘼𝙉𝙆𝙎 ▄▀▄▀

 -𝙰𝙻𝙻𝙰𝙷 𝚂𝚆𝚃 [ 𝙼𝚈 𝙶𝙾𝙳 ]  
 -𝚁𝚈𝚈𝚈 [ ᴍʏ 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ]
 -𝙾𝚁𝚃𝚄 [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]   
 -𝙻𝚆𝙴𝙽𝙽 [ 𝚃𝙴𝙰𝙲𝙷𝙴𝚁 ]   
 -𝙵𝙰𝚁𝚁𝙴𝙻𝙾𝙵𝙵𝙲 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙹𝚄𝙰𝙽𝙽 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙳𝚁𝚈𝚇𝚉 [ 𝙼𝚅𝙰𝙰? ]
 -𝚂𝙺𝚈𝚈 𝙱𝙾𝙲𝙰𝙷 𝙴𝙿𝙴𝙿 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙷𝙰𝙽𝙽𝚅𝙾𝙻𝚃𝙰 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝚁𝙰𝙵𝙵𝟺𝚄 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝙳𝚄𝙻𝚉𝚉/𝙿𝙸𝚉𝚉 [ 𝙼𝙰𝙽𝚃𝙰𝙿 ]
 -𝚄𝚂𝙴𝙽𝙸𝙽𝙶 𝚂𝙲𝚁𝙸𝙿𝚃 [ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ]`
let buttons = [
        { buttonId: ".owner", buttonText: { displayText: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ " } }, 
        { buttonId: ".start", buttonText: { displayText: "🔙Back" } }
    ];

    let buttonMessage = {
        image: G1,
	    gifPlayback: true,
        caption: tqtoo,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363390660011889@newsletter",
                newsletterName: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ "
            }
        },
        footer: "© 𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃 𝐒𝐄𝐀𝐒𝐒𝐎𝐍 𝐓𝐖𝐎",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await Neverdie.sendMessage(m.chat, buttonMessage, { quoted: loli });
}
break

case "public": { 
if (!isBot) return reply(`\`Fitur Ini Hanya Dapat Diakses Oleh Owner Bot\``)
Neverdie.public = true
reply(`*\`Successfully Changed Bot Mode To Public\`*`)
}
break

case "self":
case "private": { 
if (!isBot) return reply(`\`Fitur Ini Hanya Dapat Diakses Oleh Owner Bot\``)
Neverdie.public = false
reply(`*\`Successfully Changed Bot Mode To Self/Private\`*`)
}
break

case "addowner":{
if (!isBot) return reply(`\`KHUSUS Ryy Anjg\``)
if (!args[0]) return reply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××*_`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Neverdie.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`*\`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!\`*`)
newOwner.push(prrkek)
fs.writeFileSync("./lib/Database/owner.json", JSON.stringify(newOwner))
reply(`*\`Nomor ${prrkek} Telah Menjadi Owner Bot!!\`*`)
}
break

case "delowner":{
if (!isOwner) return reply(`\`KHUSUS Ryy Anjg\``)
if (!args[0]) return reply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××*_`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = newOwner.indexOf(ya)
newOwner.splice(unp, 1)
fs.writeFileSync("./lib/Database/owner.json", JSON.stringify(newOwner))
reply(`*\`Nomor ${ya} Telah Di Hapus Dari Database Owner Bot!\`*`)
}    
break

case "addprem":{
if (!isBot) return reply("KHUSUS Ryy Anjg")
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Neverdie.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync("./lib/Database/premium.json", JSON.stringify(premium))
reply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break

case "delprem":{
if (!isBot) return reply("KHUSUS Ryy Anjg")
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync("./lib/Database/premium.json", JSON.stringify(premium))
reply(`Nomor ${ya} Telah Di Hapus Premium!`)
}
break

case "owner":
case "ownermenu": {
await loadingl()
await loading()
let own = `
╔═══╦╗╔╗╔╦═╗─╔╦═══╦═══╗
║╔═╗║║║║║║║╚╗║║╔══╣╔═╗║
║║─║║║║║║║╔╗╚╝║╚══╣╚═╝║
║║─║║╚╝╚╝║║╚╗║║╔══╣╔╗╔╝
║╚═╝╠╗╔╗╔╣║─║║║╚══╣║║╚╗
╚═══╝╚╝╚╝╚╝─╚═╩═══╩╝╚═╝
╔═══╦══╦════╦╗─╔╦═══╦═══╗
║╔══╩╣╠╣╔╗╔╗║║─║║╔═╗║╔══╝
║╚══╗║║╚╝║║╚╣║─║║╚═╝║╚══╗
║╔══╝║║──║║─║║─║║╔╗╔╣╔══╝
║║──╔╣╠╗─║║─║╚═╝║║║╚╣╚══╗
╚╝──╚══╝─╚╝─╚═══╩╝╚═╩═══╝
========================
╔═╦═╦╦═╦╦══╦╗╔═╦╗╔╦══╗
║╬╠╗║╠╗║║╔╗║║║╬║╚╝║╔╗║
║╗╬╩╗╠╩╗║╠╣║╚╣╔╣╔╗║╠╣║
╚╩╩══╩══╩╝╚╩═╩╝╚╝╚╩╝╚╝
========================
⚙︎  𝙰𝙳𝙳𝙿𝚁𝙴𝙼
⚙︎  𝙳𝙴𝙻𝙿𝚁𝙴𝙼
⚙︎  𝙰𝙳𝙳𝙾𝚆𝙽𝙴𝚁
⚙︎  𝙳𝙴𝙻𝙾𝚆𝙽𝙴𝚁
⚙︎  𝚂𝙴𝙻𝙵
⚙︎  𝙿𝚄𝙱𝙻𝙸𝙲
⚙︎  𝙴𝙽𝙲𝚁𝚈𝙿𝚃𝙷𝙰𝚁𝙳
========================
ᖴOOᖇ YOᑌ IᑎᖴOᖇᗰᗩTIOᑎ
========================
\`𝚃𝙷𝙴 𝚂𝙲𝚁𝙸𝙿𝚃 𝙲𝚁𝙴𝙰𝚃𝙴𝙳 𝙾𝙽 𝚁𝚢𝚢𝙰𝚕𝚙𝚑𝚊\`
\`𝙳𝙾 𝚈𝙾𝚄 𝙱𝚄𝚈 𝚂𝙲𝚁𝙸𝙿𝚃? 𝙲𝙷𝙰𝚃 𝙼𝙴!! https://wa.me/\`
`
let buttons = [
        { buttonId: ".bugmenu", buttonText: { displayText: "Bug Menu" } }, 
        { buttonId: ".start", buttonText: { displayText: "Back To Menu" } }
    ];

    let buttonMessage = {
    image: G2,
	    gifPlayback: true,
        caption: own,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363390660011889@newsletter",
                newsletterName: " ⃟𝐑𝐲𝐲̶͢͠⃟𝐔𝐥𝐭𝐮𝐦𝐚𝐭͠⃟ "
            }
        },
        footer: "© 𝐍͢𝐄͡𝐕͜𝐄͡𝐑 ͢𝐃͜𝐈͡𝐄 ♱ 𝐑͡𝐄͢𝐌͜𝐀͡𝐒͢𝐓͡𝐑͜𝐄͢𝐃",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };
await Neverdie.sendMessage(m.chat, buttonMessage, { quoted: loli });
}
break

default:
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isOwner) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});